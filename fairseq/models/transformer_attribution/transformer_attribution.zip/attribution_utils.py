import torch
import torch.nn.functional as F
from torch import Tensor

# def forward_bias_decomposition(x, bias):
#     """
#         the function torch.linalg.lstsq on CUDA requires X is
#     """
#     token_len, class_len, bsz, _ = x.size()
#     component = torch.zeros((token_len, class_len, bsz)).to(x)
#     for i in range(bsz):
#         for j in range(token_len):
#             basis = x[j,:,i,:] # CT x C
#             zeros_mask = (basis == 0)[:,0]
#             full_rank_basis = basis[~zeros_mask,:] # CT' x C

#             solution = torch.linalg.lstsq(full_rank_basis.transpose(0,1), bias[:, None]).solution # CT' x 1
#             if not solution.isfinite().all() or solution.isnan().any() :
#                 import pdb
#                 pdb.set_trace()
#             component[j,~zeros_mask,i] = solution[:,0]
#     # res = torch.linalg.lstsq(x.permute(0,2,3,1), bias[None,None,:,None])

#     # assert torch.max(component.abs()) < 1.0
#     # error_bound = 10
#     # component[component.abs() > error_bound] = component[component.abs() > error_bound] / component.abs()[component.abs() > error_bound]
#     # component[:] = 0.0
#     component = component.unsqueeze(-1) * x # T x CT x B x C
#     residual = bias - component.sum(dim=1, keepdim=True)
#     x = x + component
#     return x, residual


def forward_bias_decomposition(x, bias):
    """
    x: T x CT x B x C
    bias: T x 1 x B x C
    the parameter 'bias' support boardcast
    """
    assert len(x.size()) == len(bias.size())
    assert x.size(-1) == bias.size(-1) and bias.size(1) == 1
    solution = torch.linalg.lstsq(
        x.permute(0, 2, 3, 1).cpu(),
        bias.permute(0, 2, 3, 1).cpu(),
        rcond=1e-2,
        driver="gelsd",
    ).solution  # T x B x CT x 1
    component = solution.to(x).squeeze(-1).transpose(1, 2)  # T X CT x B
    # if torch.max(component.abs()) > 10:
    #     import pdb
    #     pdb.set_trace()
    # assert torch.max(component.abs()) < 1.0
    error_bound = 10
    component[component.abs() > error_bound] = (
        component[component.abs() > error_bound]
        / component.abs()[component.abs() > error_bound]
    )
    # component[:] = 0.0
    component = component.unsqueeze(-1) * x
    residual = bias - component.sum(dim=1, keepdim=True)
    x = x + component
    return x, residual


def forward_iter_decomposition(x):
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    _x, residual = forward_bias_decomposition(x[:, 1:], residual)
    x[:, 1:] = _x
    x[:, 0:1, :, :] = residual
    return x


# sparse_rec = []


# def forward_sparse_abs_decomposition(x: Tensor, eps=1e-6):
#     # import pdb
#     # pdb.set_trace()
#     residual = x[:, 0:1, :, :]  # T x 1 x B x C
#     compositions = x[:, 1:]
#     abs_compositions = compositions.abs()
#     sum_compositions = abs_compositions.sum(dim=1, keepdim=True)
#     sum_compositions[sum_compositions == 0] = eps
#     topk_abs = abs_compositions.topk(k=abs_compositions.size(1) // 2, dim=1)[0]
#     sparse_ratio = topk_abs.sum(dim=1, keepdim=True) / sum_compositions
#     sparse_rec.append(sparse_ratio.view(-1).mean())
#     if len(sparse_rec) % 1000 == 0:
#         print("avg sparse ratio: ", torch.stack(sparse_rec).mean().item())
#     if len(sparse_rec) == 40000:
#         exit()
#     weights = abs_compositions / sum_compositions
#     x[:, 1:] += weights * residual
#     x[:, 0] = 0.0
#     return x


def forward_sparse_abs_decomposition(x: Tensor, eps=1e-6):
    # import pdb
    # pdb.set_trace()
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    abs_compositions = compositions.abs()

    mask_index = abs_compositions.topk(
        k=int(abs_compositions.size(1) * 2 / 3), dim=1, largest=False
    )[1]
    abs_compositions.scatter_(
        dim=1, index=mask_index, src=torch.zeros_like(mask_index).to(abs_compositions)
    )
    sum_compositions = abs_compositions.sum(dim=1, keepdim=True)
    sum_compositions[sum_compositions == 0] = eps
    weights = abs_compositions / sum_compositions
    x[:, 1:] += weights * residual
    x[:, 0] = 0.0
    return x


# def forward_sparse_norm_decomposition(x: Tensor, eps=1e-6):
#     residual = x[:, 0:1, :, :]  # T x 1 x B x C
#     compositions = x[:, 1:]
#     norm_compositions = torch.norm(
#         compositions, p=float("inf"), dim=-1, keepdim=True
#     )  # T x CT x B x 1
#     sum_compositions = norm_compositions.sum(dim=1, keepdim=True)  # T x 1 x B x 1
#     sum_compositions[sum_compositions == 0] = eps
#     topk_abs = norm_compositions.topk(k=norm_compositions.size(1) // 2, dim=1)[0]
#     sparse_ratio = topk_abs.sum(dim=1, keepdim=True) / sum_compositions
#     sparse_rec.append(sparse_ratio.view(-1).mean())
#     if len(sparse_rec) % 1000 == 0:
#         print("avg sparse ratio: ", torch.stack(sparse_rec).mean().item())
#     if len(sparse_rec) == 40000:
#         exit()
#     weights = norm_compositions / sum_compositions  # T x CT x B x 1
#     x[:, 1:] += weights * residual
#     x[:, 0] = 0.0
#     return x


def forward_sparse_norm_decomposition(x: Tensor, eps=1e-6):
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    norm_compositions = torch.norm(
        compositions, p=float("inf"), dim=-1, keepdim=True
    )  # T x CT x B x 1

    mask_index = norm_compositions.topk(
        k=int(norm_compositions.size(1) * 1 / 3), dim=1, largest=False
    )[1]
    norm_compositions.scatter_(1, mask_index, 0.0)
    sum_compositions = norm_compositions.sum(dim=1, keepdim=True)
    sum_compositions[sum_compositions == 0] = eps
    weights = norm_compositions / sum_compositions  # T x CT x B x 1
    x[:, 1:] += weights * residual
    x[:, 0] = 0.0
    return x


def forward_abs_decomposition(x, eps=1e-6):
    # import pdb
    # pdb.set_trace()
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    abs_compositions = compositions.abs()
    sum_compositions = abs_compositions.sum(dim=1, keepdim=True)
    sum_compositions[sum_compositions == 0] = eps
    weights = abs_compositions / sum_compositions
    x[:, 1:] += weights * residual
    x[:, 0] = 0.0
    return x


def forward_hybrid_decomposition(x, power_factor=1 / 1.5, eps=1e-6):
    def ratio_map(ratio: Tensor):
        zero_map = ratio < 0.3
        ratio[zero_map] = 0
        ratio[~zero_map] = 1

        # zero_map = ratio < 0.1
        # one_map = ratio > 0.2
        # ratio[zero_map] = 0
        # ratio[one_map] = 1
        # ratio[~zero_map & ~one_map] = 10 * (ratio[~zero_map & ~one_map] - 0.1)

    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]

    sum_compositions = compositions.sum(dim=1, keepdim=True)
    abs_compositions = compositions.abs()
    abs_sum_compositions = abs_compositions.sum(dim=1, keepdim=True)
    ratio = sum_compositions.abs() / abs_sum_compositions

    sum_compositions[sum_compositions == 0] = eps
    abs_sum_compositions[abs_sum_compositions == 0] = eps

    ratio_map(ratio)

    weights = ratio * compositions / sum_compositions
    abs_weights = (1 - ratio) * abs_compositions / abs_sum_compositions

    x[:, 1:] += weights * residual + abs_weights * residual
    x[:, 0] = 0.0
    return x

    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    norm_compositions = torch.norm(
        compositions, p=float("inf"), dim=-1, keepdim=True
    )  # T x CT x B x 1
    sum_compositions = norm_compositions.sum(dim=1, keepdim=True)  # T x 1 x B x 1
    sum_compositions[sum_compositions == 0] = eps

    weights = norm_compositions / sum_compositions  # T x CT x B x 1
    x[:, 1:] += weights * residual
    x[:, 0] = 0.0


def forward_sign_decomposition(x, eps=1e-6):
    # import pdb
    # pdb.set_trace()
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    sum_compositions = compositions.sum(dim=1, keepdim=True)
    sum_compositions[sum_compositions == 0] = eps
    weights = compositions / sum_compositions
    overflow_indices = sum_compositions.abs() < 0.2
    weights.masked_fill_(overflow_indices, 0.0)
    x[:, 1:] += weights * residual
    x[:, 0:1].masked_fill_(~overflow_indices, 0.0)
    x = forward_abs_decomposition(x)
    return x


def forward_norm_decomposition(x, eps=1e-6):
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    norm_compositions = torch.norm(
        compositions, p=float("inf"), dim=-1, keepdim=True
    )  # T x CT x B x 1
    sum_compositions = norm_compositions.sum(dim=1, keepdim=True)  # T x 1 x B x 1
    sum_compositions[sum_compositions == 0] = eps

    weights = norm_compositions / sum_compositions  # T x CT x B x 1
    x[:, 1:] += weights * residual
    x[:, 0] = 0.0
    return x


def forward_hybrid_norm_decomposition(x: Tensor, power_factor=1, eps=1e-6):
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]  # T x CT x B x C
    product = torch.matmul(residual.unsqueeze(-2), compositions.unsqueeze(-1)).squeeze(
        -1
    )  # T x CT x B x 1
    sum_product = product.sum(dim=1, keepdim=True)  # T x 1 x B x 1
    abs_product = product.abs()
    abs_sum_product = abs_product.sum(dim=1, keepdim=True)  # T x 1 x B x 1
    ratio = sum_product.abs() / abs_sum_product  # T x 1 x B x 1

    sum_product[sum_product == 0] = eps
    abs_sum_product[abs_sum_product == 0] = eps

    ratio = ratio ** power_factor
    # ratio = 1

    weights = ratio * product / sum_product  # T x CT x B x 1
    abs_weights = (1 - ratio) * abs_product / abs_sum_product  # T x CT x B x 1
    x[:, 1:] += weights * residual + abs_weights * residual
    x[:, 0] = 0.0
    return x


# def forward_hybrid_norm_decomposition(x: Tensor, power_factor=1, eps=1e-6):
#     residual = x[:, 0:1, :, :]  # T x 1 x B x C
#     compositions = x[:, 1:]  # T x CT x B x C
#     norm_index = compositions.abs().max(dim=-1, keepdim=True)[1]
#     signed_norm = torch.gather(compositions, -1, norm_index)  # T x CT x B x 1

#     sum_signed_norm = signed_norm.sum(dim=1, keepdim=True)  # T x 1 x B x 1
#     abs_signed_norm = signed_norm.abs()
#     abs_sum_signed_norm = abs_signed_norm.sum(dim=1, keepdim=True)  # T x 1 x B x 1
#     ratio = sum_signed_norm.abs() / abs_sum_signed_norm  # T x 1 x B x 1

#     sum_signed_norm[sum_signed_norm == 0] = eps
#     abs_sum_signed_norm[abs_sum_signed_norm == 0] = eps

#     # ratio = ratio ** power_factor
#     ratio = 0

#     weights = ratio * signed_norm / sum_signed_norm  # T x CT x B x 1
#     abs_weights = (1 - ratio) * abs_signed_norm / abs_sum_signed_norm  # T x CT x B x 1
#     x[:, 1:] += weights * residual + abs_weights * residual
#     x[:, 0] = 0.0
#     return x


def forward_softmax_decomposition(x, eps=1e-6):
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    norm_compositions = torch.norm(
        compositions, p=float("inf"), dim=-1, keepdim=True
    )  # T x CT x B x 1
    weights = torch.softmax(norm_compositions, dim=1)

    x[:, 1:] += weights * residual
    x[:, 0] = 0.0
    return x


def forward_norm_softmax_decomposition(x, eps=1e-6):
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    norm_compositions = torch.norm(
        compositions, p=2, dim=-1, keepdim=True
    )  # T x CT x B x 1
    sum_compositions = norm_compositions.sum(dim=1, keepdim=True)  # T x 1 x B x 1
    sum_compositions[sum_compositions == 0] = eps

    weights = norm_compositions / sum_compositions  # T x CT x B x 1

    weights = torch.softmax(weights, dim=1)  # T x CT x B x 1
    x[:, 1:] += weights * residual
    x[:, 0] = 0.0
    return x


def forward_average_decomposition(x: Tensor, eps=1e-6):
    residual = x[:, 0:1, :, :]  # T x 1 x B x C
    compositions = x[:, 1:]
    weights = torch.ones(compositions.size()[:-1]).to(compositions).unsqueeze(
        -1
    ) / compositions.size(1)
    x[:, 1:] += weights * residual
    x[:, 0] = 0.0
    return x


def forward_relu(x: torch.Tensor):
    assert len(x.size()) == 4
    x_sum = x.sum(dim=1, keepdim=True)
    zero_mask = x_sum < 0
    x = torch.masked_fill(x, zero_mask, 0.0)
    # x[zero_mask] = 0.0
    return x


def forward_gelu(x: torch.Tensor, weight1, bias1, weight2, bias2):
    assert len(x.size()) == 4
    assert weight1.size(1) == 1
    assert weight2.size(0) == 1
    s_size, c_size, bsz, h_size = x.size()
    x = forward_linear(x.view(s_size, c_size, -1).unsqueeze(-1), weight1, bias1)
    x = forward_relu(x)
    x = forward_linear(x, weight2, bias2)
    x = x.squeeze(-1).view(s_size, c_size, bsz, h_size)
    return x


def forward_linear(
    x: torch.Tensor,
    weight,
    bias,
    key_padding_mask=None,
    decompose_bias=True,
    iter_decompose=True,
):
    assert (
        len(x.size()) == 4
    )  # T x CT+1 x B X C , CT + 1 means add one residual component
    if key_padding_mask is not None:
        key_padding_mask = key_padding_mask.to(torch.bool)
        bsz, encoder_len = key_padding_mask.size()
        key_padding_mask = torch.cat(
            [torch.zeros((bsz, 1)).to(key_padding_mask), key_padding_mask], dim=1
        )
        x = torch.masked_fill(
            x, key_padding_mask.transpose(0, 1).unsqueeze(0).unsqueeze(-1), 0.0
        )
    x = x.matmul(weight.t())

    if decompose_bias:
        x[:, 0, :, :] += bias
        x = forward_sparse_norm_decomposition(x)
        # if iter_decompose:
        #     x[:, 0, :, :] += bias
        #     x = forward_iter_decomposition(x)
        # else:
        #     _x, residual = forward_bias_decomposition(x[:, 1:], bias[None, None, None, :])
        #     x[:, 1:] = _x
        #     x[:, 0:1, :, :] += residual
    else:
        x[:, 0, :, :] += bias

    return x


def forward_layer_norm(
    x, weight, bias, key_padding_mask=None, decompose_bias=True, iter_decompose=True
):
    assert len(x.size()) == 4
    if key_padding_mask is not None:
        key_padding_mask = key_padding_mask.to(torch.bool)
        bsz, encoder_len = key_padding_mask.size()
        key_padding_mask = torch.cat(
            [torch.zeros((bsz, 1)).to(key_padding_mask), key_padding_mask], dim=1
        )
        x = torch.masked_fill(
            x, key_padding_mask.transpose(0, 1).unsqueeze(0).unsqueeze(-1), 0.0
        )

    # x = x.to(torch.float64)
    # weight = weight.to(torch.float64)
    x_mean = x.mean(dim=-1, keepdim=True)
    x_std = torch.sqrt(
        torch.var(x.sum(dim=1), dim=-1, unbiased=False, keepdim=True) + 1e-5
    )
    x = (x - x_mean) * weight / x_std.unsqueeze(dim=1)
    # x = x.to(torch.float32)

    if decompose_bias:
        x[:, 0, :, :] += bias
        x = forward_sparse_norm_decomposition(x)
        # if iter_decompose:
        #     x[:, 0, :, :] += bias
        #     x = forward_iter_decomposition(x)
        # else:
        #     _x, residual = forward_bias_decomposition(x[:, 1:], bias[None, None, None, :])
        #     x[:, 1:] = _x
        #     x[:, 0:1, :, :] += residual
    else:
        x[:, 0, :, :] += bias
    return x


def forward_layer_norm_decoder(
    x, weight, bias, key_padding_mask=None, decompose_bias=True, iter_decompose=True
):
    assert len(x.size()) == 4
    assert x.size(0) == 1

    if key_padding_mask is not None:
        key_padding_mask = key_padding_mask.to(torch.bool)
        bsz, encoder_len = key_padding_mask.size()
        all_len = x.size(1)
        cat_mask = torch.zeros((bsz, all_len - encoder_len)).to(key_padding_mask)
        key_padding_mask = torch.cat(
            [cat_mask[:, 0:1], key_padding_mask, cat_mask[:, 1:]], dim=1
        )
        x = x.masked_fill(
            key_padding_mask.transpose(0, 1).unsqueeze(0).unsqueeze(-1), 0.0
        )

    x_mean = x.mean(dim=-1, keepdim=True)
    x_std = torch.sqrt(
        torch.var(x.sum(dim=1), dim=-1, unbiased=False, keepdim=True) + 1e-5
    )
    x = (x - x_mean) * weight / x_std.unsqueeze(dim=1)

    if decompose_bias:
        x[:, 0, :, :] += bias
        x = forward_sparse_norm_decomposition(x)
        # if iter_decompose:
        #     x[:, 0, :, :] += bias
        #     x = forward_iter_decomposition(x)
        # else:
        #     _x, residual = forward_bias_decomposition(x[:, 1:], bias[None, None, None, :])
        #     x[:, 1:] = _x
        #     x[:, 0:1, :, :] += residual
    else:
        x[:, 0, :, :] += bias

    return x


def check_error(x, ref_x, key_padding_mask=None, error=1e-2):
    # pass
    assert len(x.size()) == 4
    bsz = x.size(2)
    x_sub = x.sum(dim=1) - ref_x
    if key_padding_mask is not None:
        key_padding_mask = key_padding_mask.to(torch.bool)
        x_error = (
            torch.sum(
                x_sub.masked_fill(
                    key_padding_mask.transpose(0, 1).unsqueeze(-1), 0.0
                ).abs()
            )
            / bsz
        )
        assert x_error < error, f"error overflow: {x_error}"
    else:
        x_error = torch.sum(x_sub.abs()) / bsz
        assert x_error < error, f"error overflow: {x_error}"


def check_error_decoder(x, ref_x, key_padding_mask=None, error=1e-2):
    assert len(x.size()) == 4
    assert x.size(0) == 1
    bsz = x.size(2)

    if key_padding_mask is not None:
        key_padding_mask = key_padding_mask.to(torch.bool)
        bsz, encoder_len = key_padding_mask.size()
        all_len = x.size(1)
        cat_mask = torch.zeros((bsz, all_len - encoder_len)).to(key_padding_mask)
        key_padding_mask = torch.cat(
            [cat_mask[:, 0:1], key_padding_mask, cat_mask[:, 1:]], dim=1
        )
        x = x.masked_fill(
            key_padding_mask.transpose(0, 1).unsqueeze(0).unsqueeze(-1), 0.0
        )

    x_sub = x.sum(dim=1) - ref_x
    if torch.sum(x_sub.abs()) / bsz > error:
        import pdb

        pdb.set_trace()
    assert torch.sum(x_sub.abs()) / bsz < error

